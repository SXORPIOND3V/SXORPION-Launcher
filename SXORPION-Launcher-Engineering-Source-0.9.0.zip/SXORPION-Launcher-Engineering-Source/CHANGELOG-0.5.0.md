# SXORPION Launcher source 0.5.0

## Graphics groundwork
- Added native renderer library inventory for the app's current Android ABI.
- Added an explicit graphics readiness assessment that separates EGL support, packaged library presence, and actual Minecraft readiness.
- Kept renderer backends marked not launch-ready until a native build and LWJGL/window/input integration are validated.

## Vanilla 1.12.2 groundwork
- Added official Mojang version manifest lookup for 1.12.2.
- Added parser for legacy Minecraft 1.12.2 version JSON.
- Added verified HTTPS artifact downloader with expected size and SHA-1 checks.
- Added client JAR download entry point and asset-index object parsing.
- Added vanilla launch-plan builder and bounded game log buffer.
- Added dashboard controls to inspect packaged renderer libraries and fetch official version metadata.

## Not yet functional
- No native renderer binaries are bundled.
- No Minecraft game files or assets are bundled.
- No Microsoft authentication flow, full asset downloader, Android native extraction, LWJGL/window bridge, or game process launch is complete.
- Not compiled or device-tested in this environment.
