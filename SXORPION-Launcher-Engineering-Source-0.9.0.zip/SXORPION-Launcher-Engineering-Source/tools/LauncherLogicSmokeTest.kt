import dev.sxorpion.launcher.game.LegacyArgumentTokenizer

fun main() {
    val parsed = LegacyArgumentTokenizer.tokenize("--username player --userProperties \"{\\\"demo\\\":true}\" --version 1.12.2")
    check(parsed == listOf("--username", "player", "--userProperties", "{\"demo\":true}", "--version", "1.12.2")) { parsed }
    check(runCatching { LegacyArgumentTokenizer.tokenize("--username \"broken") }.isFailure)
    println("Launcher logic smoke tests passed")
}
