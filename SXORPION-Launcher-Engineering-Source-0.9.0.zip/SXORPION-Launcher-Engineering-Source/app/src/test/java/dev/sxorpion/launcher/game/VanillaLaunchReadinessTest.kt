package dev.sxorpion.launcher.game

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VanillaLaunchReadinessTest {
    @Test
    fun reportsMissingRequirementsInsteadOfClaimingReady() {
        val root = createTempDir(prefix = "sxorpion-readiness-")
        try {
            val result = VanillaLaunchReadinessChecker.inspect(
                gameRoot = root,
                clientJar = File(root, "missing.jar"),
                javaExecutable = null,
                authenticatedProfile = null,
                androidRendererReady = false
            )
            assertFalse(result.readyForCommandPreparation)
            assertTrue(result.blockers.size >= 5)
        } finally {
            root.deleteRecursively()
        }
    }
}
