package dev.sxorpion.launcher.game

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class LegacyArgumentTokenizerTest {
    @Test
    fun keepsQuotedSpacesTogether() {
        assertEquals(
            listOf("--username", "Player One", "--version", "1.12.2"),
            LegacyArgumentTokenizer.tokenize("--username \"Player One\" --version 1.12.2")
        )
    }

    @Test
    fun preservesEmptyQuotedArgument() {
        assertEquals(listOf("--demo", ""), LegacyArgumentTokenizer.tokenize("--demo \"\""))
    }

    @Test
    fun rejectsUnmatchedQuote() {
        assertThrows(IllegalArgumentException::class.java) {
            LegacyArgumentTokenizer.tokenize("--username \"Player One")
        }
    }

    @Test
    fun acceptsEscapedQuoteInsideQuotedArgument() {
        assertEquals(listOf("a\"b"), LegacyArgumentTokenizer.tokenize("\"a\\\"b\""))
    }
}
