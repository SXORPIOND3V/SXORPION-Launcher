package dev.sxorpion.launcher.game

import org.json.JSONObject

/** Minimal model for the legacy 1.12.2 version JSON format. */
data class MinecraftVersionMetadata(
    val id: String,
    val mainClass: String,
    val minecraftArguments: String,
    val clientJar: DownloadArtifact?,
    val assetIndexId: String?,
    val assetIndexUrl: String?,
    val assetIndexSha1: String?,
    val assetIndexSize: Long,
    val libraries: List<DownloadArtifact>
) {
    companion object {
        fun parse(jsonText: String): MinecraftVersionMetadata {
            val root = JSONObject(jsonText)
            val id = root.optString("id")
            require(id == "1.12.2") { "Expected Minecraft 1.12.2 metadata, got '$id'." }
            val downloads = root.optJSONObject("downloads")
            val client = downloads?.optJSONObject("client")?.toArtifact(defaultPath = "1.12.2.jar")
            val assetIndex = root.optJSONObject("assetIndex")
            val librariesJson = root.optJSONArray("libraries")
            val libraries = buildList {
                if (librariesJson != null) {
                    for (i in 0 until librariesJson.length()) {
                        val lib = librariesJson.optJSONObject(i) ?: continue
                        val artifact = lib.optJSONObject("downloads")?.optJSONObject("artifact")
                        if (artifact != null) add(artifact.toArtifact())
                    }
                }
            }
            return MinecraftVersionMetadata(
                id = id,
                mainClass = root.optString("mainClass", "net.minecraft.client.main.Main"),
                minecraftArguments = root.optString("minecraftArguments"),
                clientJar = client,
                assetIndexId = assetIndex?.optString("id")?.takeIf(String::isNotBlank),
                assetIndexUrl = assetIndex?.optString("url")?.takeIf(String::isNotBlank),
                assetIndexSha1 = assetIndex?.optString("sha1")?.takeIf(String::isNotBlank),
                assetIndexSize = assetIndex?.optLong("size", -1L) ?: -1L,
                libraries = libraries
            )
        }

        private fun JSONObject.toArtifact(defaultPath: String = "") = DownloadArtifact(
            path = optString("path", defaultPath).ifBlank { defaultPath },
            url = optString("url"),
            sha1 = optString("sha1").takeIf(String::isNotBlank),
            size = optLong("size", -1L)
        )
    }
}

data class DownloadArtifact(
    val path: String,
    val url: String,
    val sha1: String?,
    val size: Long
)
