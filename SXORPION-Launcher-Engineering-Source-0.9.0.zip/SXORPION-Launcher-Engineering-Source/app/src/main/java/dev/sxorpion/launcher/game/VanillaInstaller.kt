package dev.sxorpion.launcher.game

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Downloads the official, metadata-declared vanilla 1.12.2 files into an app-private game directory. */
class VanillaInstaller(
    private val repository: MinecraftMetadataRepository = MinecraftMetadataRepository()
) {
    data class Progress(val completed: Int, val total: Int, val current: String) {
        val fraction: Float get() = if (total <= 0) 0f else completed.toFloat() / total
    }

    data class InstallResult(
        val metadata: MinecraftVersionMetadata,
        val gameRoot: File,
        val clientJar: File,
        val assetIndexFile: File,
        val downloadedLibraries: Int,
        val downloadedAssets: Int
    )

    suspend fun install(
        gameRoot: File,
        onProgress: suspend (Progress) -> Unit = {}
    ): InstallResult = withContext(Dispatchers.IO) {
        require(gameRoot.mkdirs() || gameRoot.isDirectory) { "Cannot create game directory." }
        val metadata = repository.fetch1122Metadata()
        val assetIndex = repository.fetchAssetIndex(metadata)
        val assetIndexId = metadata.assetIndexId ?: error("Official metadata has no asset index ID.")
        val assetIndexFile = File(gameRoot, "assets/indexes/$assetIndexId.json")
        writeAtomically(assetIndexFile, assetIndex.toString(2))

        val client = metadata.clientJar ?: error("Official metadata has no client JAR entry.")
        val libraryRoot = File(gameRoot, "libraries")
        val assetsRoot = File(gameRoot, "assets/objects")
        val assets = repository.parseAssetObjects(assetIndex)
        val tasks = metadata.libraries.size + 1 + assets.size
        var completed = 0
        var libraryCount = 0
        var assetCount = 0

        repository.downloadArtifact(client, File(gameRoot, "versions/${metadata.id}"))
        completed++
        withContext(Dispatchers.Main) { onProgress(Progress(completed, tasks, "Minecraft client JAR")) }

        metadata.libraries.forEach { artifact ->
            repository.downloadArtifact(artifact, libraryRoot)
            libraryCount++
            completed++
            withContext(Dispatchers.Main) { onProgress(Progress(completed, tasks, artifact.path.substringAfterLast('/'))) }
        }

        assets.forEach { artifact ->
            repository.downloadArtifact(artifact, assetsRoot)
            assetCount++
            completed++
            withContext(Dispatchers.Main) { onProgress(Progress(completed, tasks, "Asset ${artifact.path.substringAfterLast('/').take(12)}")) }
        }

        // 1.12.2 uses the legacy virtual-assets layout. Build it from the verified object store.
        if (assetIndex.optString("virtual") == "legacy") {
            materializeLegacyAssets(assetIndex, assetsRoot, File(gameRoot, "assets/virtual/legacy"))
        }

        InstallResult(
            metadata = metadata,
            gameRoot = gameRoot,
            clientJar = File(gameRoot, "versions/${metadata.id}/${client.path.substringAfterLast('/')}"),
            assetIndexFile = assetIndexFile,
            downloadedLibraries = libraryCount,
            downloadedAssets = assetCount
        )
    }

    private fun materializeLegacyAssets(index: JSONObject, objectRoot: File, virtualRoot: File) {
        val objects = index.optJSONObject("objects") ?: return
        val keys = objects.keys()
        while (keys.hasNext()) {
            val logicalName = keys.next()
            val hash = objects.getJSONObject(logicalName).optString("hash")
            if (hash.length != 40) continue
            val source = File(objectRoot, "${hash.substring(0, 2)}/$hash")
            if (!source.isFile) continue
            val destination = File(virtualRoot, logicalName).canonicalFile
            require(destination.toPath().startsWith(virtualRoot.canonicalFile.toPath())) {
                "Invalid legacy asset path in official index."
            }
            if (!destination.isFile) {
                destination.parentFile?.mkdirs()
                source.copyTo(destination, overwrite = false)
            }
        }
    }

    private fun writeAtomically(destination: File, content: String) {
        destination.parentFile?.mkdirs()
        val temporary = File(destination.parentFile, destination.name + ".part")
        FileOutputStream(temporary).bufferedWriter(Charsets.UTF_8).use { it.write(content) }
        if (destination.exists()) destination.delete()
        check(temporary.renameTo(destination)) { "Could not save ${destination.name}." }
    }
}
