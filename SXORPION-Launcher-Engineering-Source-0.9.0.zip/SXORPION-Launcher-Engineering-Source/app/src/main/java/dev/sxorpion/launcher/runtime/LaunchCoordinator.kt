package dev.sxorpion.launcher.runtime

class LaunchCoordinator(private val backend: GameRuntimeBackend) {
    suspend fun launch(config: LaunchConfig): LaunchResult {
        val validation = config.validate()
        if (validation.isNotEmpty()) return LaunchResult.Rejected(validation)

        val status = backend.inspect()
        if (!status.available) {
            return LaunchResult.Rejected(listOf("Runtime backend unavailable: ${status.message}"))
        }
        if (config.javaMajor !in status.supportedJavaMajors) {
            return LaunchResult.Rejected(listOf("Backend does not provide Java ${config.javaMajor}."))
        }
        if (config.renderer !in status.supportedRenderers && config.renderer != RendererId.AUTO) {
            return LaunchResult.Rejected(listOf("Selected renderer is not supported by this backend."))
        }
        return backend.launch(config)
    }
}
