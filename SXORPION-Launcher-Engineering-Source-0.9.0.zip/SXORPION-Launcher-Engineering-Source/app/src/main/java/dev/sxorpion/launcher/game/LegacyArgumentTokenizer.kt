package dev.sxorpion.launcher.game

/** Tokenizes the legacy space-delimited Minecraft arguments while respecting quoted values. */
object LegacyArgumentTokenizer {
    fun tokenize(input: String): List<String> {
        val result = mutableListOf<String>()
        val token = StringBuilder()
        var quoted = false
        var escaping = false
        var tokenStarted = false

        input.forEach { char ->
            when {
                escaping -> { token.append(char); escaping = false; tokenStarted = true }
                quoted && char == '\\' -> escaping = true
                char == '\"' -> { quoted = !quoted; tokenStarted = true }
                char.isWhitespace() && !quoted -> {
                    if (tokenStarted) { result += token.toString(); token.setLength(0); tokenStarted = false }
                }
                else -> { token.append(char); tokenStarted = true }
            }
        }
        require(!quoted) { "Minecraft launch arguments contain an unmatched quote." }
        require(!escaping) { "Minecraft launch arguments end with an incomplete escape." }
        if (tokenStarted) result += token.toString()
        return result
    }
}
