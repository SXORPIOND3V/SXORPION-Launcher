package dev.sxorpion.launcher.runtime

import android.content.Context
import android.os.Build
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Properties
import java.util.concurrent.TimeUnit

enum class RuntimeState {
    NOT_INSTALLED, READY, WRONG_ARCHITECTURE, MISSING_JAVA, MISSING_METADATA, INVALID
}

data class RuntimeInspection(
    val state: RuntimeState,
    val javaHome: File,
    val javaExecutable: File,
    val detectedArchitecture: String?,
    val deviceAbis: List<String>,
    val detail: String
)

/**
 * Handles a user-imported Android JRE in the app's private storage.
 *
 * This does not download or redistribute a JRE. The user must provide a
 * runtime built for Android and their device ABI. A normal desktop JDK is
 * not suitable.
 */
class AndroidJavaRuntime(private val context: Context) {
    val javaHome: File
        get() = File(context.filesDir, "runtimes/java8")

    private val javaExecutable: File
        get() = File(javaHome, "bin/java")

    suspend fun importRuntimeFolder(treeUri: android.net.Uri): RuntimeInspection =
        withContext(Dispatchers.IO) {
            val sourceRoot = DocumentFile.fromTreeUri(context, treeUri)
                ?: return@withContext inspection(
                    RuntimeState.INVALID, null, "Could not open the selected folder."
                )

            val staging = File(context.filesDir, "runtimes/java8-importing")
            val destination = javaHome
            deleteRecursivelySafely(staging)
            if (!staging.mkdirs() && !staging.isDirectory) {
                return@withContext inspection(
                    RuntimeState.INVALID, null, "Could not create the runtime folder."
                )
            }

            try {
                copyDocumentTree(sourceRoot, staging)
                val candidate = inspectFolder(staging)
                if (candidate.state != RuntimeState.READY) {
                    deleteRecursivelySafely(staging)
                    return@withContext candidate.copy(
                        detail = "Import rejected: ${candidate.detail}"
                    )
                }

                deleteRecursivelySafely(destination)
                if (!staging.renameTo(destination)) {
                    copyFileTree(staging, destination)
                    deleteRecursivelySafely(staging)
                }
                inspectInstalled()
            } catch (e: Exception) {
                deleteRecursivelySafely(staging)
                inspection(
                    RuntimeState.INVALID, null,
                    "Import failed: ${e.message ?: e.javaClass.simpleName}"
                )
            }
        }

    suspend fun inspectInstalled(): RuntimeInspection = withContext(Dispatchers.IO) {
        inspectFolder(javaHome)
    }

    /**
     * A small feasibility check. Android linker/ABI compatibility is not
     * guaranteed by the presence of files, so the actual process result matters.
     */
    suspend fun runVersionSmokeTest(): String = withContext(Dispatchers.IO) {
        val inspection = inspectFolder(javaHome)
        if (inspection.state != RuntimeState.READY) {
            return@withContext "Runtime is not ready: ${inspection.detail}"
        }

        try {
            javaExecutable.setExecutable(true, true)
            val process = ProcessBuilder(javaExecutable.absolutePath, "-version")
                .directory(javaHome)
                .redirectErrorStream(true)
                .apply {
                    environment()["JAVA_HOME"] = javaHome.absolutePath
                    val libDirs = listOf(
                        File(javaHome, "lib"),
                        File(javaHome, "lib/server"),
                        File(javaHome, "lib/aarch64")
                    ).filter { it.isDirectory }.joinToString(":") { it.absolutePath }
                    if (libDirs.isNotBlank()) {
                        environment()["LD_LIBRARY_PATH"] =
                            libDirs + ":" + (environment()["LD_LIBRARY_PATH"] ?: "")
                    }
                }
                .start()

            val output = StringBuilder()
            val reader = process.inputStream.bufferedReader()
            val readerThread = Thread {
                try {
                    reader.forEachLine { line -> synchronized(output) { output.appendLine(line) } }
                } catch (_: Exception) { }
            }.apply { isDaemon = true; start() }

            val finished = process.waitFor(8, TimeUnit.SECONDS)

            if (!finished) {
                process.destroyForcibly()
                "Java test timed out. The runtime may be incompatible with this Android device."
            } else {
                readerThread.join(500)
                val result = synchronized(output) { output.toString().trim() }
                if (process.exitValue() == 0) {
                    "Java runtime started successfully:\n$result"
                } else {
                    "Java process exited with code ${process.exitValue()}:\n$result"
                }
            }
        } catch (e: Exception) {
            "Could not start the Java runtime: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun inspectFolder(folder: File): RuntimeInspection {
        if (!folder.exists() || !folder.isDirectory) {
            return inspection(RuntimeState.NOT_INSTALLED, null, "No Java runtime imported yet.")
        }

        val java = File(folder, "bin/java")
        if (!java.exists() || !java.isFile) {
            return inspection(RuntimeState.MISSING_JAVA, null, "Missing bin/java executable.")
        }

        val release = File(folder, "release")
        if (!release.exists()) {
            return inspection(RuntimeState.MISSING_METADATA, null, "Missing Java release metadata.")
        }

        val properties = Properties()
        runCatching { release.inputStream().use(properties::load) }
            .getOrElse {
                return inspection(RuntimeState.INVALID, null, "Could not read release metadata.")
            }

        val arch = properties.getProperty("OS_ARCH")
            ?.trim()?.trim('"')?.lowercase()
        val device = Build.SUPPORTED_ABIS.map { it.lowercase() }
        val compatible = when (arch) {
            "aarch64", "arm64", "arm64-v8a" ->
                device.any { it == "arm64-v8a" || it.contains("aarch64") }
            "arm", "arm32", "arm" ->
                device.any { it.startsWith("armeabi") }
            "x86_64", "amd64" -> device.any { it == "x86_64" }
            "x86", "i386", "i686" -> device.any { it == "x86" }
            else -> false
        }

        if (!compatible) {
            return RuntimeInspection(
                RuntimeState.WRONG_ARCHITECTURE, folder, java, arch, device,
                "Runtime architecture '$arch' does not match this device's ABIs: ${device.joinToString()}."
            )
        }

        return RuntimeInspection(
            RuntimeState.READY, folder, java, arch, device,
            "Java runtime files and architecture metadata look compatible. A launch smoke test is still required."
        )
    }

    private fun inspection(
        state: RuntimeState,
        arch: String?,
        detail: String
    ) = RuntimeInspection(
        state, javaHome, javaExecutable, arch, Build.SUPPORTED_ABIS.toList(), detail
    )

    private fun copyDocumentTree(source: DocumentFile, target: File) {
        source.listFiles().forEach { child ->
            val name = child.name ?: throw IllegalArgumentException("A runtime file has no name.")
            require(name != "." && name != ".." && !name.contains("/") && !name.contains("\\"))
            val out = File(target, name)
            if (child.isDirectory) {
                if (!out.mkdirs() && !out.isDirectory) error("Cannot create ${out.name}")
                copyDocumentTree(child, out)
            } else if (child.isFile) {
                context.contentResolver.openInputStream(child.uri).use { input ->
                    requireNotNull(input) { "Cannot read ${child.name}" }
                    FileOutputStream(out).use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun copyFileTree(source: File, target: File) {
        if (source.isDirectory) {
            if (!target.mkdirs() && !target.isDirectory) error("Cannot create ${target.path}")
            source.listFiles()?.forEach { copyFileTree(it, File(target, it.name)) }
        } else {
            source.copyTo(target, overwrite = true)
        }
    }

    private fun deleteRecursivelySafely(file: File) {
        if (file.exists()) file.deleteRecursively()
    }
}
