package dev.sxorpion.launcher.game

import java.util.concurrent.ConcurrentLinkedDeque

/** Thread-safe bounded log buffer for launcher diagnostics. */
class GameLogBuffer(private val maxLines: Int = 500) {
    private val lines = ConcurrentLinkedDeque<String>()

    fun append(line: String) {
        lines.addLast(line)
        while (lines.size > maxLines) lines.pollFirst()
    }

    fun snapshot(): List<String> = lines.toList()
    fun clear() = lines.clear()
}
