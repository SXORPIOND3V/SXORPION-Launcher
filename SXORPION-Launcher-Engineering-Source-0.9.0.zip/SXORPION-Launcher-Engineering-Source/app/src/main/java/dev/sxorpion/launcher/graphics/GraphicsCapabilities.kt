package dev.sxorpion.launcher.graphics

import android.content.Context
import android.content.pm.PackageManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GraphicsCapabilities(
    val eglAvailable: Boolean,
    val glVendor: String?,
    val glRenderer: String?,
    val glVersion: String?,
    val glslVersion: String?,
    val glExtensions: Set<String>,
    val vulkanFeatureLevel: Int?,
    val vulkanVersion: Int?,
    val deviceAbis: List<String>,
    val notes: List<String>
)

class GraphicsCapabilitiesProbe(private val context: Context) {
    suspend fun inspect(): GraphicsCapabilities = withContext(Dispatchers.Default) {
        val notes = mutableListOf<String>()
        var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
        var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
        var surface: EGLSurface = EGL14.EGL_NO_SURFACE

        var vendor: String? = null
        var renderer: String? = null
        var version: String? = null
        var glsl: String? = null
        var extensions = emptySet<String>()
        var eglOk = false

        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) error("No EGL display")
            val versions = IntArray(2)
            if (!EGL14.eglInitialize(display, versions, 0, versions, 1)) {
                error("EGL initialization failed")
            }

            val attributes = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (!EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0) ||
                count[0] == 0 || configs[0] == null
            ) error("No suitable EGL config")
            val config = configs[0] ?: error("EGL returned an empty config")

            val contextAttributes = intArrayOf(
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
                EGL14.EGL_NONE
            )
            eglContext = EGL14.eglCreateContext(
                display, config, EGL14.EGL_NO_CONTEXT, contextAttributes, 0
            )
            if (eglContext == EGL14.EGL_NO_CONTEXT) error("Could not create GLES2 context")

            val surfaceAttributes = intArrayOf(
                EGL14.EGL_WIDTH, 1,
                EGL14.EGL_HEIGHT, 1,
                EGL14.EGL_NONE
            )
            surface = EGL14.eglCreatePbufferSurface(
                display, config, surfaceAttributes, 0
            )
            if (surface == EGL14.EGL_NO_SURFACE) error("Could not create EGL probe surface")
            if (!EGL14.eglMakeCurrent(display, surface, surface, eglContext)) {
                error("Could not activate EGL probe context")
            }

            vendor = GLES20.glGetString(GLES20.GL_VENDOR)
            renderer = GLES20.glGetString(GLES20.GL_RENDERER)
            version = GLES20.glGetString(GLES20.GL_VERSION)
            glsl = GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION)
            extensions = GLES20.glGetString(GLES20.GL_EXTENSIONS)
                ?.split(' ')?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
            eglOk = true
        } catch (e: Exception) {
            notes += "OpenGL ES probe failed: ${e.message ?: e.javaClass.simpleName}"
        } finally {
            if (display != EGL14.EGL_NO_DISPLAY) {
                runCatching { EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) }
                if (surface != EGL14.EGL_NO_SURFACE) runCatching { EGL14.eglDestroySurface(display, surface) }
                if (eglContext != EGL14.EGL_NO_CONTEXT) runCatching { EGL14.eglDestroyContext(display, eglContext) }
                runCatching { EGL14.eglTerminate(display) }
            }
        }

        val pm = context.packageManager
        val vkLevel = if (Build.VERSION.SDK_INT >= 24 &&
            pm.hasSystemFeature("android.hardware.vulkan.level")
        ) runCatching { pm.getSystemAvailableFeatures().firstOrNull {
            it.name == "android.hardware.vulkan.level"
        }?.version }.getOrNull() else null

        val vkVersion = if (Build.VERSION.SDK_INT >= 24 &&
            pm.hasSystemFeature("android.hardware.vulkan.version")
        ) runCatching { pm.getSystemAvailableFeatures().firstOrNull {
            it.name == "android.hardware.vulkan.version"
        }?.version }.getOrNull() else null

        if (vkLevel == null) notes += "Android did not report a Vulkan hardware level feature."
        if (!eglOk) notes += "Renderer compatibility cannot be judged until EGL/OpenGL ES can be initialized."

        GraphicsCapabilities(
            eglAvailable = eglOk,
            glVendor = vendor,
            glRenderer = renderer,
            glVersion = version,
            glslVersion = glsl,
            glExtensions = extensions,
            vulkanFeatureLevel = vkLevel,
            vulkanVersion = vkVersion,
            deviceAbis = Build.SUPPORTED_ABIS.toList(),
            notes = notes
        )
    }
}
