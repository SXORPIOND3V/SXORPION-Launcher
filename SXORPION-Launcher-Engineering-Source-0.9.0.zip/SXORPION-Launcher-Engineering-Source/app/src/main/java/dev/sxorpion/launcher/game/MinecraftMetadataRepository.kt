package dev.sxorpion.launcher.game

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Downloads official Mojang metadata and individual metadata-declared artifacts. */
class MinecraftMetadataRepository {
    companion object {
        private const val VERSION_MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 30_000
    }

    suspend fun fetch1122Metadata(): MinecraftVersionMetadata = withContext(Dispatchers.IO) {
        val manifestText = readHttpsText(VERSION_MANIFEST)
        val versions = JSONObject(manifestText).getJSONArray("versions")
        val versionUrl = (0 until versions.length())
            .map { versions.getJSONObject(it) }
            .firstOrNull { it.optString("id") == "1.12.2" }
            ?.optString("url")
            ?.takeIf(String::isNotBlank)
            ?: error("Minecraft 1.12.2 was not found in the official version manifest.")
        MinecraftVersionMetadata.parse(readHttpsText(versionUrl))
    }

    suspend fun fetchAssetIndex(metadata: MinecraftVersionMetadata): JSONObject = withContext(Dispatchers.IO) {
        val address = metadata.assetIndexUrl ?: error("Version metadata does not include an asset index URL.")
        val text = readHttpsText(address)
        metadata.assetIndexSize.takeIf { it >= 0L }?.let { expected ->
            require(text.toByteArray(Charsets.UTF_8).size.toLong() == expected) { "Asset index size verification failed." }
        }
        metadata.assetIndexSha1?.let { expected ->
            val actual = sha1(text.toByteArray(Charsets.UTF_8))
            require(actual.equals(expected, ignoreCase = true)) { "Asset index SHA-1 verification failed." }
        }
        JSONObject(text)
    }

    suspend fun downloadClientJar(metadata: MinecraftVersionMetadata, gameRoot: File): File = withContext(Dispatchers.IO) {
        val artifact = metadata.clientJar ?: error("Version metadata does not include a client JAR download.")
        downloadArtifact(artifact, File(gameRoot, "versions/${metadata.id}"))
    }

    fun parseAssetObjects(assetIndex: JSONObject): List<DownloadArtifact> {
        val objects = assetIndex.optJSONObject("objects") ?: error("Asset index has no objects map.")
        return buildList {
            val keys = objects.keys()
            while (keys.hasNext()) {
                val entry = objects.getJSONObject(keys.next())
                val hash = entry.optString("hash")
                if (hash.length != 40 || hash.any { it !in '0'..'9' && it !in 'a'..'f' }) continue
                val path = "${hash.substring(0, 2)}/$hash"
                add(DownloadArtifact(
                    path = path,
                    url = "https://resources.download.minecraft.net/$path",
                    sha1 = hash,
                    size = entry.optLong("size", -1L)
                ))
            }
        }
    }

    suspend fun downloadArtifact(artifact: DownloadArtifact, destinationRoot: File): File = withContext(Dispatchers.IO) {
        require(artifact.url.startsWith("https://")) { "Only HTTPS artifact URLs are accepted." }
        require(artifact.path.isNotBlank()) { "Artifact path is empty." }
        val root = destinationRoot.canonicalFile
        val destination = File(root, artifact.path.replace('/', File.separatorChar)).canonicalFile
        require(destination.toPath().startsWith(root.toPath())) { "Artifact path escapes the download directory." }
        destination.parentFile?.mkdirs()
        if (destination.isFile && (artifact.size < 0L || destination.length() == artifact.size)) {
            val hashMatches = artifact.sha1?.let { sha1(destination).equals(it, ignoreCase = true) } ?: true
            if (hashMatches) return@withContext destination
        }
        val connection = (URL(artifact.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        try {
            val status = connection.responseCode
            require(status in 200..299) { "Artifact download failed with HTTP $status." }
            val temporary = File(destination.parentFile, destination.name + ".part")
            try {
                connection.inputStream.use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
                if (artifact.size >= 0L) require(temporary.length() == artifact.size) {
                    "Downloaded size mismatch for ${artifact.path}."
                }
                artifact.sha1?.let { expected ->
                    val actual = sha1(temporary)
                    require(actual.equals(expected, ignoreCase = true)) { "SHA-1 verification failed for ${artifact.path}." }
                }
                if (destination.exists()) destination.delete()
                check(temporary.renameTo(destination)) { "Could not move verified artifact into place." }
                destination
            } catch (error: Throwable) {
                temporary.delete()
                throw error
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun readHttpsText(address: String): String {
        require(address.startsWith("https://")) { "Only HTTPS metadata URLs are accepted." }
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        return try {
            val status = connection.responseCode
            require(status in 200..299) { "Metadata request failed with HTTP $status." }
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun sha1(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-1")
        digest.update(bytes)
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha1(file: File): String {
        val digest = MessageDigest.getInstance("SHA-1")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
