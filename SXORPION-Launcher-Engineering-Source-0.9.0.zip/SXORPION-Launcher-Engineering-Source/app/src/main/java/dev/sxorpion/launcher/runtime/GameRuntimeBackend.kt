package dev.sxorpion.launcher.runtime

/**
 * Adapter boundary for a separately licensed and tested Android Java runtime.
 * A real implementation must manage runtime files, native libraries, game
 * assets, classpath, environment, input and renderer lifecycle.
 */
interface GameRuntimeBackend {
    suspend fun inspect(): BackendStatus
    suspend fun launch(config: LaunchConfig): LaunchResult
    suspend fun stop()
}

data class BackendStatus(
    val available: Boolean,
    val runtimeName: String,
    val supportedJavaMajors: Set<Int>,
    val supportedRenderers: Set<RendererId>,
    val message: String
)

sealed interface LaunchResult {
    data class Started(val processId: Int?) : LaunchResult
    data class Rejected(val reasons: List<String>) : LaunchResult
    data class Failed(val reason: String) : LaunchResult
}
