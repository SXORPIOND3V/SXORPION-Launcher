package dev.sxorpion.launcher.profile

data class RenderTuning(
    val renderDistanceChunks: Int,
    val particles: ParticleLevel,
    val entityDistancePercent: Int,
    val mipmaps: Int,
    val targetFps: Int,
    val resolutionScalePercent: Int
)

enum class ParticleLevel { MINIMAL, DECREASED, ALL }

enum class PerformanceProfile(
    val displayName: String,
    val tuning: RenderTuning,
    val description: String
) {
    POTATO(
        "Extreme Potato",
        RenderTuning(4, ParticleLevel.MINIMAL, 50, 0, 30, 70),
        "Lowest-cost starting point for experimental low-end testing."
    ),
    BALANCED(
        "Balanced",
        RenderTuning(6, ParticleLevel.DECREASED, 75, 1, 45, 85),
        "Moderate visual quality with a conservative workload."
    ),
    PERFORMANCE(
        "Performance+",
        RenderTuning(8, ParticleLevel.ALL, 100, 2, 60, 100),
        "Higher visual settings; use only when the device has headroom."
    )
}
