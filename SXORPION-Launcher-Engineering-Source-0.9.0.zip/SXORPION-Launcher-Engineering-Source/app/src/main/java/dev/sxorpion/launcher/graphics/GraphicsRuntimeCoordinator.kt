package dev.sxorpion.launcher.graphics

import android.content.Context

/** Consolidates the graphics probe and native-library checks for the launch pipeline. */
class GraphicsRuntimeCoordinator(context: Context) {
    private val registry = NativeRendererRegistry(context)

    data class GraphicsReadiness(
        val selected: RendererId,
        val eglAvailable: Boolean,
        val nativeLibraryPresent: Boolean,
        val readyForMinecraft: Boolean,
        val explanation: String
    )

    fun assess(selected: RendererId, eglAvailable: Boolean): GraphicsReadiness {
        if (selected == RendererId.AUTO) {
            return GraphicsReadiness(
                selected, eglAvailable, false, false,
                "AUTO selection is not wired to a tested Minecraft window backend yet."
            )
        }
        val native = registry.inspect(selected)
        val ready = eglAvailable && native.libraryPresent
        return GraphicsReadiness(
            selected, eglAvailable, native.libraryPresent, false,
            if (!eglAvailable) "Android EGL context is unavailable."
            else if (!native.libraryPresent) native.detail
            else "Native library detected, but LWJGL/window/context hand-off is not validated. Not launch-ready."
        )
    }

    fun inspectLibraries() = registry.availableRenderers()
}
