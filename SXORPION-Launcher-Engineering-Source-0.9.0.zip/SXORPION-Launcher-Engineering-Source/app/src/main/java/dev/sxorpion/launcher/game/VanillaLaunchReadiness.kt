package dev.sxorpion.launcher.game

import java.io.File

/** Reports local prerequisites without claiming that Android native rendering is ready. */
data class VanillaLaunchReadiness(
    val readyForCommandPreparation: Boolean,
    val blockers: List<String>,
    val warnings: List<String>
)

object VanillaLaunchReadinessChecker {
    fun inspect(
        gameRoot: File,
        clientJar: File,
        javaExecutable: File?,
        authenticatedProfile: AuthenticatedMinecraftProfile?,
        androidRendererReady: Boolean
    ): VanillaLaunchReadiness {
        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (!clientJar.isFile || clientJar.length() == 0L) blockers += "Minecraft client JAR is not installed."
        if (!File(gameRoot, "assets/indexes").isDirectory) blockers += "Minecraft asset indexes are missing."
        if (!File(gameRoot, "libraries").isDirectory) blockers += "Minecraft libraries are missing."
        if (javaExecutable == null || !javaExecutable.isFile) blockers += "A compatible Android Java runtime is not installed."
        if (authenticatedProfile == null || authenticatedProfile.accessToken.isBlank()) blockers += "A Microsoft-authenticated Minecraft profile is not available."
        if (!androidRendererReady) blockers += "Android LWJGL/window/native-renderer integration is not installed."
        warnings += "A successful file install does not prove the game can launch on this device."
        warnings += "Never share Microsoft passwords or access tokens in screenshots or logs."
        return VanillaLaunchReadiness(blockers.isEmpty(), blockers, warnings)
    }
}
