package dev.sxorpion.launcher.memory

/**
 * Conservative UI hint only. This is not a promise that Android will allow
 * this heap, nor a replacement for measuring the separate game process.
 */
object MemoryBudgetPlanner {
    fun suggestedHeapMb(totalRamMb: Long, availableRamMb: Long): Int {
        if (totalRamMb <= 0L) return 512
        val reserve = maxOf(1536L, totalRamMb * 40L / 100L)
        val byTotal = totalRamMb - reserve
        val byAvailable = availableRamMb - 768L
        val raw = minOf(byTotal, byAvailable, 2048L)
        return raw.coerceIn(512L, 2048L).toInt()
    }
}
