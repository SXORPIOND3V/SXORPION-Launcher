package dev.sxorpion.launcher.game

import java.io.File

/** Builds, but deliberately does not execute, the Java 8 command for a vanilla launch. */
data class VanillaJvmCommand(
    val executable: File,
    val workingDirectory: File,
    val arguments: List<String>
) {
    fun asDisplayText(): String = (listOf(executable.absolutePath) + arguments)
        .joinToString(" ") { token ->
            if (token.any(Char::isWhitespace)) "\"${token.replace("\"", "\\\"")}\"" else token
        }
}

class VanillaJvmCommandBuilder {
    fun build(
        javaExecutable: File,
        plan: VanillaLaunchPlan,
        nativeLibraryDirectory: File,
        minHeapMb: Int = 256,
        maxHeapMb: Int = 1024,
        extraJvmArguments: List<String> = emptyList()
    ): VanillaJvmCommand {
        require(javaExecutable.isFile) { "Java executable is missing." }
        require(plan.isComplete) { "Launch plan is incomplete: ${plan.missingFiles.joinToString()}" }
        require(nativeLibraryDirectory.isDirectory) { "Android native-library directory is missing." }
        require(minHeapMb >= 128 && maxHeapMb >= minHeapMb && maxHeapMb <= 4096) {
            "Invalid memory limits."
        }
        require(extraJvmArguments.none {
            it.startsWith("-javaagent") || it.startsWith("-agentlib") || it.startsWith("-agentpath")
        }) { "Java agent arguments are not accepted." }

        val args = buildList {
            add("-Xms${minHeapMb}M")
            add("-Xmx${maxHeapMb}M")
            add("-Djava.library.path=${nativeLibraryDirectory.absolutePath}")
            add("-Dorg.lwjgl.librarypath=${nativeLibraryDirectory.absolutePath}")
            add("-Djava.net.preferIPv4Stack=true")
            addAll(extraJvmArguments)
            add("-cp")
            add(plan.classpathString())
            add(plan.mainClass)
            addAll(plan.gameArguments)
        }
        return VanillaJvmCommand(javaExecutable, plan.workingDirectory, args)
    }
}
