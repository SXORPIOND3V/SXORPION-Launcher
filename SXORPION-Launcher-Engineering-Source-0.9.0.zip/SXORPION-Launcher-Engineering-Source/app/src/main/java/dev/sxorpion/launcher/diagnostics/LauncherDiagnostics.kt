package dev.sxorpion.launcher.diagnostics

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local-only diagnostics. It deliberately avoids account IDs, serial numbers and file contents. */
class LauncherDiagnostics(private val context: Context) {
    private val crashFile = File(context.filesDir, "diagnostics/latest-crash.txt")

    fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                crashFile.parentFile?.mkdirs()
                val trace = StringWriter().also { error.printStackTrace(PrintWriter(it)) }.toString()
                crashFile.writeText(
                    "SXORPION Launcher crash\n" +
                        "Time: ${timestamp()}\n" +
                        "Thread: ${thread.name}\n\n" + trace
                )
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun createReport(): String {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also(activityManager::getMemoryInfo)
        val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
        val version = if (Build.VERSION.SDK_INT >= 28) {
            "${packageInfo.versionName} (${packageInfo.longVersionCode})"
        } else {
            "${packageInfo.versionName} (${packageInfo.versionCode})"
        }
        return buildString {
            appendLine("SXORPION LAUNCHER DIAGNOSTICS")
            appendLine("Generated: ${timestamp()}")
            appendLine("App version: $version")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("Device RAM: ${memory.totalMem / 1_048_576} MB total")
            appendLine("Available RAM: ${memory.availMem / 1_048_576} MB")
            appendLine("Low-memory mode: ${memory.lowMemory}")
            appendLine("Crash log present: ${crashFile.exists()}")
            appendLine()
            appendLine("Privacy: this report contains basic device/app diagnostics only.")
            appendLine("It does not include account credentials, device identifiers, or personal files.")
            appendLine("Review the report before sharing it.")
            if (crashFile.exists()) {
                appendLine()
                appendLine("LATEST CRASH LOG")
                appendLine(runCatching { crashFile.readText().take(20_000) }
                    .getOrDefault("Could not read the local crash log."))
            }
        }
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date())
}
