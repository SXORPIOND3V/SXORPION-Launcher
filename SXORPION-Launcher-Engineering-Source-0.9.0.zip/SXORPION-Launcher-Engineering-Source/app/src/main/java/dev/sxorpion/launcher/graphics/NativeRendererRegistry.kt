package dev.sxorpion.launcher.graphics

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Checks which renderer libraries are actually packaged for this app process.
 * This is deliberately a detector, not a claim that a renderer is operational:
 * Minecraft still needs a compatible LWJGL/window/input bridge.
 */
class NativeRendererRegistry(context: Context) {
    private val nativeDir = File(context.applicationInfo.nativeLibraryDir)

    data class RendererAvailability(
        val renderer: RendererId,
        val libraryPresent: Boolean,
        val expectedLibrary: String,
        val abi: String,
        val detail: String
    )

    fun inspect(renderer: RendererId): RendererAvailability {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val library = libraryName(renderer)
        val present = library != null && File(nativeDir, library).isFile
        return RendererAvailability(
            renderer = renderer,
            libraryPresent = present,
            expectedLibrary = library ?: "No native library required by AUTO",
            abi = abi,
            detail = when {
                renderer == RendererId.AUTO -> "AUTO needs a real renderer-selection bridge before game launch."
                present -> "Library file found. Native initialization and Minecraft compatibility remain unverified."
                else -> "Required $library is not packaged for this app's $abi process."
            }
        )
    }

    fun availableRenderers(): List<RendererAvailability> = listOf(
        RendererId.GL4ES,
        RendererId.ZINK,
        RendererId.ANGLE,
        RendererId.MOBILE_GLUES
    ).map(::inspect)

    private fun libraryName(renderer: RendererId): String? = when (renderer) {
        RendererId.AUTO -> null
        RendererId.GL4ES -> "libgl4es.so"
        RendererId.ZINK -> "libzink.so"
        RendererId.ANGLE -> "libEGL_angle.so"
        RendererId.MOBILE_GLUES -> "libmobileglues.so"
    }
}
