package dev.sxorpion.launcher.game

import java.io.File

/** A validated description of the files and arguments needed for a vanilla launch. */
data class VanillaLaunchPlan(
    val workingDirectory: File,
    val mainClass: String,
    val classpath: List<File>,
    val gameArguments: List<String>,
    val missingFiles: List<String>
) {
    val isComplete: Boolean get() = missingFiles.isEmpty() && classpath.isNotEmpty()
    fun classpathString(separator: String = File.pathSeparator): String = classpath.joinToString(separator) { it.absolutePath }
}

class VanillaLaunchPlanBuilder {
    fun build(
        gameDirectory: File,
        metadata: MinecraftVersionMetadata,
        clientJar: File,
        libraryRoot: File,
        profile: AuthenticatedMinecraftProfile,
        gameAssetsDirectory: File,
        width: Int = 854,
        height: Int = 480
    ): VanillaLaunchPlan {
        require(profile.username.isNotBlank()) { "Player name cannot be empty." }
        require(profile.accessToken.isNotBlank()) { "A valid Minecraft access token is required." }
        require(profile.uuid.matches(Regex("[0-9a-fA-F]{32}|[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"))) {
            "The authenticated Minecraft profile UUID is invalid."
        }
        require(width in 320..7680 && height in 240..4320) { "Invalid game resolution." }
        val missing = mutableListOf<String>()
        if (!clientJar.isFile) missing += "Minecraft client JAR is missing: ${clientJar.name}"
        val libraries = metadata.libraries.map { artifact ->
            val root = libraryRoot.canonicalFile
            val file = File(root, artifact.path.replace('/', File.separatorChar)).canonicalFile
            require(file.toPath().startsWith(root.toPath())) { "Library path escapes library directory." }
            artifact to file
        }
        libraries.forEach { (artifact, file) ->
            if (!file.isFile) missing += "Library missing: ${artifact.path}"
        }
        if (!gameAssetsDirectory.isDirectory) missing += "Assets directory is missing."
        val classpath = (listOf(clientJar) + libraries.map { it.second }).distinct()
        val replacements = mapOf(
            "\${auth_player_name}" to profile.username,
            "\${version_name}" to metadata.id,
            "\${game_directory}" to gameDirectory.absolutePath,
            "\${assets_root}" to gameAssetsDirectory.absolutePath,
            "\${assets_index_name}" to (metadata.assetIndexId ?: "1.12"),
            "\${auth_uuid}" to profile.uuid.replace("-", ""),
            "\${auth_access_token}" to profile.accessToken,
            "\${user_type}" to profile.userType,
            "\${version_type}" to "release",
            "\${user_properties}" to "{}",
            "\${resolution_width}" to width.toString(),
            "\${resolution_height}" to height.toString()
        )
        val args = LegacyArgumentTokenizer.tokenize(metadata.minecraftArguments)
            .map { token -> replacements.entries.fold(token) { value, entry -> value.replace(entry.key, entry.value) } }
        val unresolved = args.filter { Regex("\\$\\{[^}]+}").containsMatchIn(it) }
        if (unresolved.isNotEmpty()) missing += "Unresolved launch placeholders: ${unresolved.joinToString()}"
        return VanillaLaunchPlan(gameDirectory, metadata.mainClass, classpath, args, missing)
    }
}

/** Credentials come from a successful official account-authentication flow. Do not persist accessToken. */
data class AuthenticatedMinecraftProfile(
    val username: String,
    val uuid: String,
    val accessToken: String,
    val userType: String = "msa"
)
