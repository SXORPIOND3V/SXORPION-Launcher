package dev.sxorpion.launcher.memory

import android.os.Debug
import kotlin.math.max

data class ProcessMemorySnapshot(
    val pssMb: Int,
    val heapUsedMb: Int,
    val heapMaxMb: Int,
    val nativeHeapAllocatedMb: Int
)

class ProcessMemorySampler {
    fun snapshot(): ProcessMemorySnapshot {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return ProcessMemorySnapshot(
            pssMb = Debug.getPss(),
            heapUsedMb = bytesToMb(used),
            heapMaxMb = bytesToMb(runtime.maxMemory()),
            nativeHeapAllocatedMb = bytesToMb(Debug.getNativeHeapAllocatedSize())
        )
    }

    private fun bytesToMb(bytes: Long): Int = max(0L, bytes / MB).toInt()

    companion object { private const val MB = 1024L * 1024L }
}
