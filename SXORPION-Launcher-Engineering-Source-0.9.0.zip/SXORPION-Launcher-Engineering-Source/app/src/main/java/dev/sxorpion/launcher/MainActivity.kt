package dev.sxorpion.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import dev.sxorpion.launcher.diagnostics.LauncherDiagnostics
import dev.sxorpion.launcher.device.DeviceProfiler
import dev.sxorpion.launcher.graphics.GraphicsCapabilities
import dev.sxorpion.launcher.graphics.GraphicsCapabilitiesProbe
import dev.sxorpion.launcher.graphics.GraphicsProfile
import dev.sxorpion.launcher.graphics.NativeRendererRegistry
import dev.sxorpion.launcher.game.MinecraftMetadataRepository
import dev.sxorpion.launcher.game.VanillaInstaller
import dev.sxorpion.launcher.memory.MemoryBudgetPlanner
import dev.sxorpion.launcher.memory.ProcessMemorySampler
import dev.sxorpion.launcher.profile.PerformanceProfile
import dev.sxorpion.launcher.runtime.AndroidJavaRuntime
import dev.sxorpion.launcher.runtime.RuntimeInspection
import dev.sxorpion.launcher.runtime.RuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val diagnostics = LauncherDiagnostics(this)
        diagnostics.installCrashHandler()
        val profiler = DeviceProfiler(this)
        val sampler = ProcessMemorySampler()
        val javaRuntime = AndroidJavaRuntime(this)
        val graphicsProbe = GraphicsCapabilitiesProbe(this)
        val rendererRegistry = NativeRendererRegistry(this)
        val metadataRepository = MinecraftMetadataRepository()
        val vanillaInstaller = VanillaInstaller(metadataRepository)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val clipboard = LocalClipboardManager.current
                var diagnosticsText by remember { mutableStateOf("Diagnostics have not been generated yet.") }
                var device by remember { mutableStateOf(profiler.snapshot()) }
                var process by remember { mutableStateOf(sampler.snapshot()) }
                var profile by remember { mutableStateOf(PerformanceProfile.POTATO) }
                var runtimeInspection by remember { mutableStateOf<RuntimeInspection?>(null) }
                var runtimeMessage by remember { mutableStateOf("Checking for an imported Java runtime...") }
                var graphics by remember { mutableStateOf<GraphicsCapabilities?>(null) }
                var graphicsMessage by remember { mutableStateOf("Graphics capabilities have not been checked yet.") }
                var graphicsProfile by remember { mutableStateOf(GraphicsProfile.LOW_END) }
                var rendererStatus by remember { mutableStateOf("Native renderer libraries have not been packaged in this build.") }
                var metadataStatus by remember { mutableStateOf("Minecraft 1.12.2 files have not been installed yet.") }
                var installRunning by remember { mutableStateOf(false) }
                var installProgress by remember { mutableStateOf(0f) }
                var installDetail by remember { mutableStateOf("Install the official vanilla files into this app's private storage.") }
                val scope = rememberCoroutineScope()
                val folderPicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocumentTree()
                ) { uri ->
                    if (uri != null) {
                        runtimeMessage = "Importing runtime folder..."
                        scope.launch {
                            runtimeInspection = javaRuntime.importRuntimeFolder(uri)
                            runtimeMessage = runtimeInspection?.detail ?: "Runtime import did not return a result."
                        }
                    }
                }
                LaunchedEffect(Unit) {
                    runtimeInspection = javaRuntime.inspectInstalled()
                    runtimeMessage = runtimeInspection?.detail ?: "Runtime not checked."
                }
                LaunchedEffect(Unit) {
                    while (true) {
                        device = profiler.snapshot()
                        process = sampler.snapshot()
                        delay(2000)
                    }
                }
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("🦂 SXORPION LAUNCHER", style = MaterialTheme.typography.headlineSmall)
                        Text("Engineering dashboard • Source milestone 0.9.0")
                        MetricCard("Device RAM", "${device.totalRamMb} MB total", "${device.availableRamMb} MB currently available")
                        MetricCard("App process", "${process.pssMb} MB PSS", "PSS includes a proportional share of shared memory")
                        MetricCard("This app's Java heap", "${process.heapUsedMb} / ${process.heapMaxMb} MB", "This is not Minecraft's heap; the game runtime is not integrated yet.")
                        Text("Performance profile", style = MaterialTheme.typography.titleLarge)
                        PerformanceProfile.values().forEach { option ->
                            FilterChip(
                                selected = profile == option,
                                onClick = { profile = option },
                                label = { Text(option.displayName) }
                            )
                        }
                        val suggested = MemoryBudgetPlanner.suggestedHeapMb(device.totalRamMb, device.availableRamMb)
                        MetricCard("Experimental heap suggestion", "$suggested MB", "Starting estimate only. Must be benchmarked with the real game process.")
                        Text("Java 8 runtime", style = MaterialTheme.typography.titleLarge)
                        Text(runtimeInspection?.state?.name ?: "CHECKING")
                        Text(runtimeMessage, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { folderPicker.launch(null) }) {
                            Text("Import Android Java runtime folder")
                        }
                        OutlinedButton(
                            enabled = runtimeInspection?.state == RuntimeState.READY,
                            onClick = {
                                runtimeMessage = "Running Java version test..."
                                scope.launch {
                                    runtimeMessage = javaRuntime.runVersionSmokeTest()
                                }
                            }
                        ) {
                            Text("Test Java runtime")
                        }
                        Text(
                            "The selected folder must be the extracted Android JRE root containing bin/java and a release file. A desktop JDK is not suitable.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Divider()
                        Text("Graphics engine", style = MaterialTheme.typography.titleLarge)
                        OutlinedButton(onClick = {
                            rendererStatus = rendererRegistry.availableRenderers().joinToString("\n") {
                                "${it.renderer}: ${if (it.libraryPresent) "library found" else "not installed"} • ${it.abi} • ${it.detail}"
                            }
                        }) { Text("Check packaged renderer libraries") }
                        Text(rendererStatus, style = MaterialTheme.typography.bodySmall)
                        Text(graphicsMessage, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            graphicsMessage = "Checking EGL, OpenGL ES and Vulkan capabilities..."
                            scope.launch {
                                graphics = graphicsProbe.inspect()
                                graphicsMessage = if (graphics?.eglAvailable == true) {
                                    "Graphics API probe completed. This does not mean a Minecraft renderer is installed."
                                } else {
                                    graphics?.notes?.joinToString("\n") ?: "Graphics probe failed."
                                }
                            }
                        }) {
                            Text("Detect phone graphics")
                        }
                        graphics?.let { caps ->
                            MetricCard(
                                "GPU renderer",
                                caps.glRenderer ?: "Not detected",
                                "Vendor: ${caps.glVendor ?: "Unknown"}"
                            )
                            MetricCard(
                                "OpenGL ES",
                                caps.glVersion ?: "Not detected",
                                "GLSL: ${caps.glslVersion ?: "Unknown"}"
                            )
                            MetricCard(
                                "Vulkan",
                                caps.vulkanVersion?.toString() ?: "Not reported",
                                "Hardware level: ${caps.vulkanFeatureLevel?.toString() ?: "Not reported"}"
                            )
                        }
                        Text("Graphics quality profile", style = MaterialTheme.typography.titleMedium)
                        GraphicsProfile.values().forEach { option ->
                            FilterChip(
                                selected = graphicsProfile == option,
                                onClick = { graphicsProfile = option },
                                label = { Text(option.title) }
                            )
                        }
                        Text(
                            "Selected profile: ${graphicsProfile.tuning.renderScalePercent}% resolution scale, ${graphicsProfile.tuning.maxFps} FPS cap. These are planned settings; they are not yet applied to Minecraft.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Divider()
                        Text("Step 4 • Vanilla Minecraft 1.12.2", style = MaterialTheme.typography.titleLarge)
                        Button(
                            enabled = !installRunning,
                            onClick = {
                                installRunning = true
                                installProgress = 0f
                                installDetail = "Fetching official Mojang metadata..."
                                scope.launch {
                                    metadataStatus = runCatching {
                                        val root = java.io.File(filesDir, "minecraft")
                                        val result = vanillaInstaller.install(root) { progress ->
                                            installProgress = progress.fraction
                                            installDetail = "${progress.completed}/${progress.total}: ${progress.current}"
                                        }
                                        "Vanilla ${result.metadata.id} files installed. ${result.downloadedLibraries} libraries and ${result.downloadedAssets} asset objects checked. Client: ${result.clientJar.name}."
                                    }.getOrElse { "Install failed: ${it.message ?: it.javaClass.simpleName}" }
                                    installRunning = false
                                    if (!installRunning) installDetail = "Install operation finished. Check the result above."
                                }
                            }
                        ) { Text(if (installRunning) "Installing Minecraft..." else "Install vanilla Minecraft 1.12.2") }
                        LinearProgressIndicator(progress = installProgress, modifier = Modifier.fillMaxWidth())
                        Text(installDetail, style = MaterialTheme.typography.bodySmall)
                        Text(metadataStatus, style = MaterialTheme.typography.bodySmall)
                        Text("This downloads official Mojang metadata, the client JAR, listed Java libraries and asset objects into app-private storage. It does not install desktop native binaries or launch the game yet. Android-compatible native libraries, Microsoft authentication and the graphics/window bridge are still required.", style = MaterialTheme.typography.bodySmall)
                        Text("Minecraft 1.12.2 + Forge / RLCraft are target workloads, not supported in this prototype yet.")
                        Divider()
                        Text("Release diagnostics", style = MaterialTheme.typography.titleLarge)
                        Text("Generate a local report to help identify crashes and device compatibility issues.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { diagnosticsText = diagnostics.createReport() }) {
                            Text("Generate diagnostics report")
                        }
                        OutlinedButton(
                            enabled = diagnosticsText != "Diagnostics have not been generated yet.",
                            onClick = { clipboard.setText(AnnotatedString(diagnosticsText)) }
                        ) { Text("Copy report") }
                        Text(diagnosticsText, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Text(detail, style = MaterialTheme.typography.bodySmall)
        }
    }
}
