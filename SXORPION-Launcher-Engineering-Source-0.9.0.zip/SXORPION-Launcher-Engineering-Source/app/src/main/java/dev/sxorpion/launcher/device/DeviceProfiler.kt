package dev.sxorpion.launcher.device

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Debug

data class DeviceSnapshot(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val lowMemory: Boolean,
    val memoryClassMb: Int,
    val largeMemoryClassMb: Int,
    val supportedAbis: List<String>,
    val sdkInt: Int,
    val manufacturer: String,
    val model: String
)

class DeviceProfiler(context: Context) {
    private val appContext = context.applicationContext
    private val activityManager =
        appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun snapshot(): DeviceSnapshot {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return DeviceSnapshot(
            totalRamMb = info.totalMem / MB,
            availableRamMb = info.availMem / MB,
            lowMemory = info.lowMemory,
            memoryClassMb = activityManager.memoryClass,
            largeMemoryClassMb = activityManager.largeMemoryClass,
            supportedAbis = Build.SUPPORTED_ABIS.toList(),
            sdkInt = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL
        )
    }

    companion object { private const val MB = 1024L * 1024L }
}
