package dev.sxorpion.launcher.runtime

import dev.sxorpion.launcher.graphics.RendererId

data class LaunchConfig(
    val minecraftVersion: String = "1.12.2",
    val forgeVersion: String = "14.23.5.2860",
    val javaMajor: Int = 8,
    val minHeapMb: Int = 256,
    val maxHeapMb: Int = 1024,
    val renderer: RendererId = RendererId.AUTO,
    val extraJvmArgs: List<String> = emptyList(),
    val profileId: String = "POTATO"
) {
    fun validate(): List<String> = buildList {
        if (minecraftVersion != "1.12.2") add("This milestone is scoped to Minecraft 1.12.2.")
        if (javaMajor != 8) add("Minecraft 1.12.2 target requires a Java 8-compatible game runtime.")
        if (minHeapMb < 128) add("Minimum heap is unrealistically low.")
        if (maxHeapMb < minHeapMb) add("Maximum heap must be greater than or equal to minimum heap.")
        if (maxHeapMb > 4096) add("Heap exceeds the current safety ceiling for this prototype.")
        if (extraJvmArgs.any { it.contains("-javaagent") || it.contains("-agentlib") }) {
            add("Agent injection arguments are not accepted by the prototype validator.")
        }
    }

    fun toJvmMemoryArgs(): List<String> = listOf("-Xms${minHeapMb}M", "-Xmx${maxHeapMb}M")
}
