package dev.sxorpion.launcher.graphics

/**
 * Native renderer integration boundary.
 *
 * The interface is intentionally not backed by placeholder .so files.
 * A real adapter must load a correctly licensed native build for the
 * selected ABI and expose its documented configuration.
 */
interface RendererBackend {
    val id: RendererId
    fun isInstalled(): Boolean
    fun prepareEnvironment(): Map<String, String>
    fun shutdown()
}

/**
 * GL4ES documents these environment variables. Keep this adapter minimal;
 * do not apply undocumented settings or assume the same values suit every GPU.
 */
class Gl4esEnvironmentAdapter : RendererBackend {
    override val id = RendererId.GL4ES

    override fun isInstalled(): Boolean = false // Set true only after packaged native library verification.

    override fun prepareEnvironment(): Map<String, String> = mapOf(
        "LIBGL_ES" to "2",
        "LIBGL_GL" to "21"
    )

    override fun shutdown() = Unit
}
