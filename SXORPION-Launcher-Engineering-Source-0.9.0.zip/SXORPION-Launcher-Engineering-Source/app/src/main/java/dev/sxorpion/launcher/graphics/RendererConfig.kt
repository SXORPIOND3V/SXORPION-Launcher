package dev.sxorpion.launcher.graphics

enum class RendererId { AUTO, GL4ES, ZINK, ANGLE, MOBILE_GLUES }

data class GraphicsTuning(
    val renderScalePercent: Int,
    val maxFps: Int,
    val textureLimit: TextureLimit,
    val disableFancyGraphics: Boolean,
    val reduceParticles: Boolean
)

enum class TextureLimit { LOW, MEDIUM, HIGH, NATIVE }

enum class GraphicsProfile(
    val title: String,
    val tuning: GraphicsTuning
) {
    LOW_END("Potato Graphics", GraphicsTuning(70, 30, TextureLimit.LOW, true, true)),
    BALANCED("Balanced Graphics", GraphicsTuning(85, 45, TextureLimit.MEDIUM, true, true)),
    QUALITY("Quality Graphics", GraphicsTuning(100, 60, TextureLimit.NATIVE, false, false))
}

data class RendererSelection(
    val renderer: RendererId = RendererId.AUTO,
    val profile: GraphicsProfile = GraphicsProfile.LOW_END
)

data class RendererAssessment(
    val renderer: RendererId,
    val selectable: Boolean,
    val reason: String
)

object RendererCompatibility {
    fun assess(
        renderer: RendererId,
        capabilities: GraphicsCapabilities,
        nativeLibraryInstalled: Boolean
    ): RendererAssessment {
        if (renderer == RendererId.AUTO) {
            return RendererAssessment(renderer, true, "Let the integrated runtime backend choose a compatible renderer.")
        }
        if (!nativeLibraryInstalled) {
            return RendererAssessment(renderer, false, "Renderer library is not installed in this launcher build.")
        }
        if (!capabilities.eglAvailable) {
            return RendererAssessment(renderer, false, "OpenGL ES/EGL probe did not succeed.")
        }
        return when (renderer) {
            RendererId.GL4ES -> RendererAssessment(
                renderer, true,
                "EGL is available. This is only a preliminary check; GL4ES native ABI and game compatibility still need testing."
            )
            RendererId.ZINK -> {
                val vulkan = capabilities.vulkanVersion != null && capabilities.vulkanFeatureLevel != null
                RendererAssessment(
                    renderer, vulkan,
                    if (vulkan) "Vulkan is reported. Zink still needs a matching Mesa build and feature validation."
                    else "Required Vulkan capability information was not reported by Android."
                )
            }
            RendererId.ANGLE -> RendererAssessment(
                renderer, true,
                "EGL is available. ANGLE package/build integration and Minecraft compatibility still need testing."
            )
            RendererId.MOBILE_GLUES -> RendererAssessment(
                renderer, true,
                "EGL is available. MobileGlues native build, ABI and Minecraft compatibility still need testing."
            )
            RendererId.AUTO -> RendererAssessment(renderer, true, "Automatic selection.")
        }
    }
}
