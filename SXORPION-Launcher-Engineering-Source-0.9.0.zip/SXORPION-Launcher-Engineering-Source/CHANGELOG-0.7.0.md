# SXORPION Launcher 0.7.0 — source update

- Added quote-aware parsing for legacy Minecraft launch arguments.
- Launch-plan builder now requires a populated authenticated profile and validates UUID format.
- Added launch-readiness reporting that separates downloaded files from Android runtime/renderer/auth blockers.
- Installer progress callbacks are dispatched to the Android main thread.
- Added Step 4 status, user action list, and third-party integration/license review.
- Bumped Android app version to 0.7.0.

This is a source-only engineering milestone. It is not compiled as an APK and has not launched Minecraft.
