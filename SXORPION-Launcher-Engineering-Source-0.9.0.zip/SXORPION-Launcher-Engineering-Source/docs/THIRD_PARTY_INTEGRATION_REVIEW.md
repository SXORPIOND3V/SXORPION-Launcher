# Third-party integration and licensing review

Potential Android Minecraft backend references reviewed on 2026-11-11:

- Fold Craft Launcher (FCL) is an Android Java Edition launcher under GPL-3.0. Its current English README describes using the Amethyst-Android backend and lists numerous third-party dependencies and their licenses. Reusing FCL source or components can impose license and notice obligations; do not copy code or binaries blindly.
- FCL lists Amethyst-Android, LWJGL3 Android patches, GL4ES/NG-GL4ES, MobileGlues, Mesa/Zink, ANGLE, OpenJDK, and audio/input components. Several have different licenses and some listed items have unresolved/unknown or restrictive licensing.
- Microsoft authentication requires an OAuth application/client ID and a correctly configured public-client flow. The launcher must use the user's own official sign-in and must never collect Microsoft passwords directly.

Before adopting an Android backend, choose the launcher license and decide whether to (a) make a compliant GPL-compatible derivative of an existing launcher backend, or (b) maintain a clean independent integration with separately licensed dependencies. This is a project-level choice, not something to silently decide for the user.
