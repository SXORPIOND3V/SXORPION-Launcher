# Benchmark protocol

Do not call a profile optimized until it passes repeatable tests.

For each device + Android version + GPU driver + renderer:
1. Reboot, wait 2 minutes, record available RAM.
2. Launch clean Minecraft 1.12.2, wait at title screen for 2 minutes.
3. Load the same test world and seed.
4. Record 1%, median and 99% frame time if available; average FPS alone hides stutter.
5. Walk the same route for 10 minutes, including chunk boundaries.
6. Record process PSS, Java heap used/max, native heap, Android low-memory state and crash logs.
7. Repeat three times per heap/render profile.
8. Test Forge without mods, then RLCraft, then individual optional performance-heavy mods.

Change one variable at a time. Keep device temperature and background app conditions as consistent as possible. Do not compare results from different worlds or different render distances as if they were controlled tests.
