# What the user will need to do (only device/account steps)

The developer prepares source code, integration adapters, documentation, and build fixes. The user should not need to edit Kotlin files.

When a test build is ready, the remaining user actions are expected to be:
1. Build/install the APK on the Android phone using the documented phone-based workflow (unless a trusted build pipeline is established).
2. Import or approve a compatible Android Java runtime if the launcher does not bundle one legally and safely.
3. Sign in through the official Microsoft account page when authentication is integrated. Never send credentials or access tokens to the developer/chat.
4. Run the test and share non-sensitive error logs/screenshots. Remove account names, tokens, email addresses, and other private data first.
5. Confirm the final app name, logo, distribution choice, and project license before any public release.

No user action is required at the current source-preparation stage.
