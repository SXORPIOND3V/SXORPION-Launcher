# Step 4 status — Vanilla Minecraft 1.12.2

## Implemented in source 0.7.0
- Fetches the official Minecraft version manifest and resolves the exact 1.12.2 metadata entry.
- Downloads the metadata-declared client JAR, regular library artifacts, asset index, and asset objects.
- Checks declared file sizes and SHA-1 hashes and rejects paths that escape the selected game directory.
- Builds the legacy virtual-assets directory required by 1.12.2.
- Prepares a launch plan and validates required files and profile fields.
- Tokenizes legacy launch arguments while respecting quoted values.
- Sends installer progress callbacks on the main thread for safe UI updates.

## Not complete / not verified
This is not a playable vanilla launcher yet. The project still lacks an integrated Android JVM process supervisor, patched LWJGL2-to-LWJGL3 compatibility layer, Android window/input/audio bridge, renderer native binaries, and a completed official Microsoft/Xbox/Minecraft account flow. The installed files have not been verified by launching Minecraft on a device.

## Why the Android backend is a separate integration
Desktop Minecraft 1.12.2 metadata describes desktop Java libraries and native classifiers. Android requires an adapted runtime and graphics/window stack; merely placing desktop libraries on a Java classpath cannot make the game render.

## Security notes
- The launch-plan builder now requires a non-empty access token from a successful account flow; it no longer defaults to a dummy token.
- Do not store access tokens in preferences, logs, crash reports, or screenshots.
- No Microsoft password or token should ever be requested in this chat.
