# Step 3 and Step 4 engineering status — source 0.6.0

## Step 3 — graphics engine groundwork

Added a native renderer library registry and a graphics readiness coordinator. The expected `.so` names in the registry are this project's packaging conventions, not a claim that upstream projects publish those exact filenames. The app can distinguish Android EGL availability from whether a renderer library is actually packaged. Detecting a `.so` file does not prove Minecraft compatibility.

Still required before Step 3 can be called operationally complete:
- Build and package legally compatible native renderer binaries for each supported Android ABI.
- Integrate a tested LWJGL/window/input/audio/context bridge for Minecraft 1.12.2.
- Validate GL calls, shaders, textures, framebuffer behavior and input on physical devices.
- Benchmark and fix device-specific issues.

No renderer binary is included. No Minecraft rendering compatibility is claimed.

## Step 4 — vanilla 1.12.2 install and launch preparation

Implemented in source:
- Official Mojang version manifest lookup and 1.12.2 legacy metadata parsing.
- Download of the client JAR and metadata-listed Java library artifacts.
- Asset-index parsing, index persistence, and download of SHA-1-addressed asset objects.
- Size/SHA-1 verification when metadata supplies those values; verified files are reused on repeat installs.
- Legacy virtual asset materialization when the asset index declares `virtual: legacy`.
- Install progress UI and app-private game-data directory.
- Launch-plan validation, legacy argument placeholder substitution, and JVM command construction.
- Bounded log buffer for later process diagnostics.

Still required before a playable vanilla launch:
- Import and successfully smoke-test a compatible Android Java 8 runtime on a physical device.
- Implement Microsoft/Xbox/Minecraft account authentication and secure token handling. No password collection is implemented.
- Add Android-compatible native library extraction/loading and a tested LWJGL 2 window/input/audio/graphics bridge.
- Connect the command builder to a process runner and the tested graphics backend.
- Run a real launch test, inspect logs and fix runtime-specific failures.

The current app can prepare and download the vanilla 1.12.2 data set, and the source can construct a launch command. It does not execute that command or launch the game yet. Step 4 is therefore **download/launch-preparation complete in source, end-to-end launch incomplete**. Step 3 remains a prerequisite for rendering.
