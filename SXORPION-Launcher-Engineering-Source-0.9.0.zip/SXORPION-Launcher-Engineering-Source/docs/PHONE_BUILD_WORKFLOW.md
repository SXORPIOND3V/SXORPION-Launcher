# Phone-friendly APK build workflow

This source snapshot includes a GitHub Actions build workflow. It allows the Android project to be built on GitHub-hosted Linux runners, so the developer's phone does not need a full Android SDK installed.

## What the workflow does

1. Checks out the repository.
2. Installs JDK 17 and Android SDK platform 35/build tools 35.0.0.
3. Uses Gradle 8.9 with Android Gradle Plugin 8.7.3.
4. Runs local unit tests.
5. Builds `app-debug.apk`.
6. Uploads the APK as an Actions artifact for 14 days.

## One-time repository setup (user action)

1. Create a private repository on GitHub named `SXORPION-Launcher`.
2. Upload the **contents** of this source folder to the repository root. The `.github/workflows/android-build.yml` file must appear at `.github/workflows/android-build.yml`, not inside another nested ZIP folder.
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Select **Android build**, choose **Run workflow**, and run it on `main`.
5. Wait for the workflow to finish. A green check means the CI build and unit tests passed.
6. Open the successful run, scroll to **Artifacts**, and download `sxorpion-launcher-debug-apk`.
7. Extract the artifact ZIP; it contains `app-debug.apk`.
8. Transfer/install that APK on the test phone. Android may ask to allow installation from the browser/file manager used to open it.

## Safety and privacy

- Keep the repository private while the project is experimental.
- Never put Microsoft passwords, access tokens, signing keys, or personal game data in the repository or build logs.
- The current debug APK is not a release-signed Play Store package.
- A successful Android build only proves the app compiles. It does not prove Minecraft can launch; the Java runtime, native renderer/LWJGL bridge, authentication, and end-to-end game process are still unfinished.

## Build environment used by CI

- JDK 17
- Android SDK platform 35
- Android build-tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
