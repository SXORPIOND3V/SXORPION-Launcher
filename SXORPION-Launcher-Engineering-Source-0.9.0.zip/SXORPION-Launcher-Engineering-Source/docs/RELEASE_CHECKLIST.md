# SXORPION Launcher release checklist

## Build and installation
- [ ] GitHub Actions completes unit tests and `assembleDebug` successfully.
- [ ] Install the APK on a clean Android device and confirm first launch.
- [ ] Confirm app upgrade and uninstall behaviour.
- [ ] Check that app-private runtime/game files are handled as documented.

## Stability and compatibility
- [ ] Test on the target low-end phone and at least one other Android device.
- [ ] Verify Android Java runtime import and `java -version` on-device.
- [ ] Verify renderer libraries, ABI and graphics backend on-device.
- [ ] Launch vanilla Minecraft 1.12.2, then Forge, then RLCraft.
- [ ] Record startup time, memory use, crashes and sustained frame rate.

## Privacy and security
- [ ] Review every Android permission and remove anything unnecessary.
- [ ] Confirm diagnostics are local-only and user-controlled.
- [ ] Never include access tokens, passwords, device serials or personal files in reports.
- [ ] Review third-party library licences and notices before distribution.
- [ ] Do not publish until authentication and account handling are implemented safely.

## Release
- [ ] Set final version number and release notes.
- [ ] Build a signed release APK/AAB with a securely stored signing key.
- [ ] Verify checksum and archive the exact release artifact.
- [ ] Publish known limitations and supported device/Android versions.

**Current status:** not release-ready. The project is still an engineering prototype; Minecraft runtime, renderer integration and actual game launch remain unverified.
