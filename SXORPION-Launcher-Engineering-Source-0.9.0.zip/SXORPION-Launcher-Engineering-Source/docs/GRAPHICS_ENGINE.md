# Step 3 — Graphics engine groundwork

## Why this exists
Minecraft Java 1.12.2 expects desktop OpenGL behavior. Android exposes OpenGL ES through EGL, so a compatible translation/renderer layer is needed. Renderer choice depends on GPU, driver, native ABI, game version and mods.

## Research findings
- GL4ES translates desktop OpenGL 1.5/2.1 calls to OpenGL ES 1.1/2.0. Its documentation describes Android support and environment variables such as `LIBGL_ES` and `LIBGL_GL`.
- Zink translates OpenGL to Vulkan. Mesa's documentation lists Vulkan requirements even for the OpenGL 2.1 feature level. Vulkan availability alone does not prove a phone can run Zink.
- Amethyst lists multiple renderer projects and their licenses/dependencies. We must review the exact project version and redistribution terms before bundling anything.

## Implemented in this milestone
- EGL/OpenGL ES 2.0 probe using a temporary 1x1 pbuffer context.
- Captures GL vendor, renderer, version, GLSL version and extension list.
- Reads Android-reported Vulkan hardware level/version features.
- Renderer selection model for AUTO, GL4ES, Zink, ANGLE and MobileGlues.
- Preliminary compatibility assessment that does not confuse a detected API with a working renderer.
- Three graphics tuning profiles.
- GL4ES environment adapter using documented baseline variables.

## Not implemented
- No GL4ES, Zink, ANGLE or MobileGlues native `.so` libraries are included.
- No LWJGL/GLFW integration.
- No Minecraft window or frame presentation.
- No renderer has been benchmarked on the target Realme device.
- No FPS improvement is claimed.

## Why AUTO is the safe default
A renderer is only truly supported after its native library is packaged for the phone's ABI, loaded successfully, creates a context, and renders the target Minecraft version without regressions. A simple GPU/API probe cannot prove those things.

## References
- GL4ES overview: https://github.com/ptitSeb/gl4es
- GL4ES usage/environment variables: https://ptitseb.github.io/gl4es/USAGE.html
- GL4ES Android build notes: https://ptitseb.github.io/gl4es/COMPILE.html
- Mesa Zink requirements: https://docs.mesa3d.org/drivers/zink.html
- Amethyst dependencies/licenses: https://github.com/Tungstend/Amethyst-Android
