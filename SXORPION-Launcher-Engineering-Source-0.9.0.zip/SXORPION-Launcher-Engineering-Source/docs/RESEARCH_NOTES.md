# Research notes — Android Java launchers

Research snapshot: 2026-11-11. Check project repositories again before making implementation decisions.

## PojavLauncher
The original PojavLauncher repository says the project is discontinued/archived and identifies Amethyst-Android as its successor. Its build notes describe prebuilt JRE artifacts, custom LWJGL, a GLFW stub and a Gradle application module. This confirms that a working launcher is much more than a Compose UI.

## Amethyst-Android
Amethyst is based on PojavLauncher. Its README documents a multi-architecture JRE build, LWJGL, GLFW stub, native OpenGL support and OpenAL. It is the most relevant reference for the runtime/backend integration boundary.

## Fold Craft Launcher
FCL combines HMCL-derived launcher functionality with an Amethyst Android backend. Its feature set includes multiple game versions, loaders, Java runtime management, controls, mod/resource management and renderer pluginization. Good reference for launcher product architecture, not proof that every feature is suitable for our target hardware.

## Zalith Launcher 2
Zalith Launcher 2 describes itself as a redesigned Android launcher using PojavLauncher as its core launch engine and Jetpack Compose / Material 3 for UI. Useful UI architecture reference.

## Renderers
Android devices generally expose OpenGL ES while Minecraft Java expects desktop OpenGL. A translation/compatibility layer is therefore a central part of the runtime. GL4ES is described as performance-oriented for older OpenGL targets; Zink and ANGLE solve different compatibility/extension cases. Renderer support varies by game version, GPU, driver and mods. Benchmark on each target; never label one renderer "fastest on every phone".

## Memory profiling
Android's memory guidance distinguishes PSS, USS and RSS and recommends inspecting process memory over time with tools such as `dumpsys meminfo` and `dumpsys procstats`. The launcher must not treat Java heap as total process memory. Native and graphics allocations also matter.

## Architectural conclusion
Build our own user-facing launcher and profiling/configuration layer. Integrate a backend only after license review and device tests. Do not fork-and-rebrand a project or redistribute its components without meeting its license terms and attribution obligations.
