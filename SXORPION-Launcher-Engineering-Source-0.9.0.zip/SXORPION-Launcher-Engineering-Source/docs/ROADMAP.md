# SXORPION Launcher roadmap

## M0 — Engineering scaffold (this source package)
- [x] Kotlin/Compose Android shell
- [x] Device RAM and process memory telemetry
- [x] Conservative heap hint
- [x] Performance profile model
- [x] Launch configuration validation
- [x] Runtime backend interface
- [ ] Compile and run on device

## M1 — Runtime feasibility
- [x] Add runtime-folder importer and Java runtime inspection groundwork
- [x] Add Java process smoke-test code (not device-tested)
- [ ] Confirm Android ABI and GPU on target phone
- [ ] Select backend after license review
- [ ] Confirm Java 8 ARM64 runtime packaging
- [ ] Confirm LWJGL/GLFW and native library loading
- [ ] Confirm GL4ES compatibility for 1.12.2 + Forge
- [ ] Launch vanilla 1.12.2 on a clean test instance

## M1.5 — Graphics feasibility groundwork
- [x] Add EGL/OpenGL ES capability probe
- [x] Add Vulkan feature detection
- [x] Add renderer selection and compatibility model
- [x] Add graphics tuning profiles
- [x] Add manual graphics probe to the dashboard
- [ ] Integrate a licensed native renderer and test context creation

## M2 — Forge
- [ ] Install Forge 1.12.2 into isolated instance
- [ ] Verify Forge version and libraries
- [ ] Launch Forge without mods
- [ ] Capture logs and crash reports

## M3 — Memory lab
- [ ] Measure game-process PSS, Java heap, native heap and graphics pressure
- [ ] Compare 512 / 768 / 1024 / 1280 MB heap configurations
- [ ] Track cold launch, world load, 10-minute play, dimension change and shutdown
- [ ] Avoid claiming improvement without repeatable measurements

## M4 — RLCraft
- [ ] Add RLCraft only after Forge baseline is stable
- [ ] Test mod load time, world creation, chunk traversal and combat scenes
- [ ] Record FPS frame-time percentiles, memory peaks and crashes
- [ ] Establish compatibility notes per device/GPU/renderer

## M5 — Optimization
- [ ] Profile CPU, GPU and memory separately
- [ ] Apply optional graphics presets
- [ ] Test mod overhead individually (e.g. foliage / chunk animation)
- [ ] Keep visual features configurable; do not silently remove mods

## Engineering update 0.6.0

- Step 3: added renderer-library inventory and an explicit readiness assessment boundary. It can report missing native libraries rather than treating EGL detection as proof of a working game renderer. **Still blocked on packaged native renderer builds and a validated LWJGL/window/input bridge.**
- Step 4: added official Mojang 1.12.2 metadata retrieval, legacy version metadata parsing, verified artifact-download primitives, client-JAR download entry point, launch-plan argument substitution, and bounded log buffering. **This is launch-pipeline groundwork, not a runnable Minecraft client.**

## Engineering update 0.6.0

- Step 4: added a complete source-level vanilla data installer for the Mojang-declared client JAR, libraries, asset index and asset objects, including hash/size verification and legacy virtual assets. Added progress UI, launch argument validation and JVM command construction.
- Step 4 remains **not playable yet**: account authentication, Android-native library loading, LWJGL/window/input/audio integration, process execution and a real-device launch test remain outstanding.
- Step 3 remains **not operationally complete** until compatible native renderer binaries and a tested graphics bridge are integrated.


## Updated engineering gate (0.7.0)
- Step 4 source groundwork: implemented.
- Step 4 playable verification: blocked pending Android JVM + LWJGL/window/native renderer + official account authentication integration.
- Do not mark Steps 3 or 4 complete until a vanilla 1.12.2 launch succeeds on a physical Android device and logs confirm a clean shutdown.


## Step 9 — Release preparation (source groundwork)
- Add local diagnostics reports with app/device/Android/ABI/RAM information.
- Save the latest uncaught crash locally for user-controlled review.
- Do not upload diagnostics automatically; the user chooses whether to copy/share them.
- Keep credentials, device serials, account IDs and personal files out of the report.
- Before public release, complete a real Android build, install/uninstall checks, runtime and game launch tests, permissions review, license review and device testing.

This step is source groundwork only. It does not mean the launcher is release-ready.
