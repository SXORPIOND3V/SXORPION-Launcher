# 0.9.0 — Release preparation groundwork

- Added local diagnostics report generation.
- Added local uncaught-crash log capture.
- Reports avoid account credentials, serial numbers and personal file contents.
- Added a release-readiness checklist.
- Updated source version metadata to 0.9.0.

Not a release build: no Android APK was compiled or device-tested. Minecraft runtime, renderer and game launch are not yet verified.
