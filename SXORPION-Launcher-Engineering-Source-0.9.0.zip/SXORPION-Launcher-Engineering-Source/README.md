# SXORPION Launcher — engineering source 0.9.0

An Android launcher engineering prototype targeting Minecraft Java 1.12.2, with Forge/RLCraft as later goals.

## Included

- Kotlin + Jetpack Compose Android application scaffold.
- Device RAM and app-process memory diagnostics.
- Android Java runtime folder importer and `java -version` smoke-test attempt.
- EGL/OpenGL ES and Android Vulkan capability probe.
- Renderer library inventory and graphics-readiness checks.
- Official Minecraft 1.12.2 metadata/client/library/asset installation pipeline with integrity checks.
- Vanilla launch-plan validation, legacy argument tokenizer and JVM command preparation.
- Bounded diagnostic log buffer.
- Unit tests for argument tokenization and launch-readiness checks.
- GitHub Actions workflow for hosted Android builds and APK artifact upload.

## Important status

This is source code, not an APK. The Android project has not yet been built in this environment or tested on a physical device. The CI workflow is prepared but must be run from a GitHub repository.

The app does not yet launch Minecraft. Microsoft authentication, Android-compatible Java runtime validation, ABI-specific native renderer binaries, LWJGL/window/input/audio integration, and a successful end-to-end game launch remain outstanding. Forge and RLCraft are later milestones.

## Build requirements

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

## Easiest phone-based build route

See [`docs/PHONE_BUILD_WORKFLOW.md`](docs/PHONE_BUILD_WORKFLOW.md). GitHub Actions performs the Android build on a hosted runner, so the phone only needs to manage the repository and download the resulting APK artifact.
