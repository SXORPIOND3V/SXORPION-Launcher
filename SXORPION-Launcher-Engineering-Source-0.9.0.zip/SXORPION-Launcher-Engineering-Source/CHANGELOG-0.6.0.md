# SXORPION Launcher source 0.6.0

## Step 4 — vanilla installation and launch preparation
- Added `VanillaInstaller` to download the official 1.12.2 client JAR, listed library artifacts, asset index and all referenced asset objects.
- Added size/SHA-1 verification when Mojang metadata supplies those values, plus reuse of already-verified files.
- Added legacy virtual asset materialization for indexes that declare `virtual: legacy`.
- Added an install button and progress display to the launcher dashboard.
- Improved launch-plan validation, including safe library paths and unresolved placeholder detection.
- Added a JVM command builder that assembles Java 8 memory settings, native library paths, classpath, main class and game arguments.
- Documented the exact blockers preventing a real game launch.

## Not completed / not claimed
- No actual Minecraft process is started by this version.
- No Microsoft authentication flow is included.
- No Android-compatible LWJGL/window/input/audio/native renderer bridge is included.
- No Android Java runtime is bundled.
- No Android Gradle build or physical-device test has been performed.
