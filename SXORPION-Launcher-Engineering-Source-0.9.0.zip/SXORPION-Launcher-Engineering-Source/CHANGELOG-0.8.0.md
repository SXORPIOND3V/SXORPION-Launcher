# 0.8.0 — Phone-friendly build preparation

- Added GitHub Actions workflow to run Android unit tests and assemble a debug APK on a hosted runner.
- Pinned CI toolchain to JDK 17, Gradle 8.9, Android SDK 35 and build-tools 35.0.0.
- Added unit tests for legacy argument tokenization and launch-readiness blocker reporting.
- Updated Android app version metadata and dashboard milestone label to 0.8.0.
- Added a step-by-step phone-friendly CI build guide.

This release is source-only. No APK was built in this environment and no Minecraft launch was tested.
